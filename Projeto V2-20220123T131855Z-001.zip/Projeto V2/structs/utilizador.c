#include <stdio.h>
#include "utilizador.h"

void criarUtilizador(){
	int numero, NIF, tempo;
 	char codigo[5];
 	float media;
 	
 	printf("Qual o NIF: ");
 	scanf("%d", &NIF);
 	
 	printf("Qual o c�digo do meio: ");
 	gets(codigo);
 	
 	printf("Tempo utilizado: ");
 	scanf("%d", &tempo);
 	
 	
}


