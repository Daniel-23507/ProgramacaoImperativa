typedef struct{
	char codigo[5], tipo[20];
	float custo;
	int autonomia;
} meioMobilidade;


