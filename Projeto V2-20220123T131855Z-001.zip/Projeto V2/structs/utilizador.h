typedef struct{
	int numero, NIF;
 	char Codigo[5];
 	float tempo, media;
} Utilizador;
